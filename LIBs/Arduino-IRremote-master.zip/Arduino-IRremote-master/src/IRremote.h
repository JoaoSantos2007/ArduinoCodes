/**
 * @file IRremote.h
 *
 * @brief Stub for backward compatibility
 */

#ifndef IRremote_h
#define IRremote_h

#include "IRremote.hpp"

#endif // IRremote_h
#pragma once

